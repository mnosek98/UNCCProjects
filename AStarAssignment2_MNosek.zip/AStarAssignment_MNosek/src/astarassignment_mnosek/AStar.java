package astarassignment_mnosek;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Description: This program uses A* and Manhattan methodology to create a path from a start
 * coordinate to an end coordinate. This specific program uses GUIs to visualize the path.
 * 
 * @author Margaret Nosek
 */ 

public class AStar extends JFrame implements ActionListener {

    //initializes all the GUI buttons and windows (part of the visualization)

    private final int WINDOW_WIDTH = 1150;
    private final int WINDOW_HEIGHT = 600;
    private static JButton[][] button = new JButton[15][15];

    /**
     *
     */
    public AStar() {
        
        //sets the layout for the GUI (window size and 15x15 table)
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridLayout(15, 15));

        //Creates an array that contains the names of each button
        //uses a 2-D array to fill each button name with the coordinates
        String[][] buttonName = new String[15][15];
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 15; j++) {
                buttonName[i][j] = "btn" + i + " " + j;
            }
        }

        //creates the 225 buttons or tiles
        for (int i = 0; i < button.length; i++) {

            for (int j = 0; j < button[i].length; j++) {
                button[i][j] = new JButton(i + ", " + (j));
                //picks 10% of the blocks to make unpathable 
                if (Math.random() < 0.1) {
                    button[(i)][j].setBackground(Color.DARK_GRAY);
                    add(button[i][j]);
                //otherwise, creates ActionListener on other buttons
                } else {
                    button[i][j].addActionListener(this); 
                    add(button[i][j]);
                }
            }
        }
        //makes the board appear
        setVisible(true);
    }

    //creates a 15x15 game board of type Node
    private Node[][] gameBoard = new Node[15][15];

    /**
     *
     * @param args
     * @throws Exception
     */
    public static void main(String args[]) throws Exception {

        //initializes all of the start coordinate names and goal coordinate names
        int startX, startY, goalX, goalY;
        Node StartNode;
        Node goalNode;
        //Creates a new AStar object
        new AStar();

        //while(button[startX][startY].getBackground() != Color.DARK_GRAY){
        //prompts the user for the start and goal coordinates
        //stores the start and goal coordinates
        String startRowStr = JOptionPane.showInputDialog("Enter starting x ");
        startX = Integer.parseInt(startRowStr);

        String startColStr = JOptionPane.showInputDialog("Enter starting y: ");
        startY = Integer.parseInt(startColStr);

        //checks to see if the start point is pathable
        if(button[startX][startY].getBackground() == Color.DARK_GRAY){
            System.out.println("You have selected an unpathable start.");
        }else{
           //makes the starting point green
           button[startX][startY].setBackground(Color.green); 
        }

        String endRowStr = JOptionPane.showInputDialog("Enter goal x: ");
        goalX = Integer.parseInt(endRowStr);

        String endColStr = JOptionPane.showInputDialog("Enter goal y: ");
        goalY = Integer.parseInt(endColStr);
        //checks to see if the goal point is pathable
        if(button[goalX][goalY].getBackground() == Color.DARK_GRAY){
            System.out.println("You have selected an unpathable goal.");
        }else{
           //makes the goal coordinate yellow
           button[goalX][goalY].setBackground(Color.YELLOW); 
        }        
        //creates the start and goal nodes based off the user input
        StartNode = new Node(startX, startY, 0);
        goalNode = new Node(goalX, goalY, 0);
        //initializes the start g and hueristic value 
        StartNode.setG(0);
        StartNode.setH(getH(StartNode, goalNode));
        //prints out the heuristic value
        System.out.print("h= " + getH(StartNode, goalNode));
        System.out.println();
        //calculates F
        StartNode.setF();
        
        //In the output window, prints out the start and goal coordinates
        System.out.println("Start point is : " + startX + " " + startY + " End point is : " + goalX + " " + goalY);
        //calls the solve method to find the best route to the goal
        solve(StartNode, goalNode, button);

        button[startX][startY].setBackground(Color.green); //keeps the start point green when solved

    }

    /**
     * Description: Creates the 15x15 board with 1s for unpathable blocks and 0s for 
     * pathable blocks
     *
     * @return gameBoard
     */
    public Node[][] createBoard() {

        for (int i = 0; i < 22; i++) {
            int x = (int) (Math.random() * 15);
            int y = (int) (Math.random() * 15);
            gameBoard[x][y] = new Node(x, y, 1);
        } // end loop

        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 15; j++) {
                if (gameBoard[i][j] == null) {
                    gameBoard[i][j] = new Node(i, j, 0);
                } // end if
            } // end loop 2
        } // end loop 1
        return gameBoard;
    } // end method

    /**
     * Description: prints out the new board
     *
     * @param x 
     */
    public static void printBoard(Node[][] x) {
        //uses a nested for loop to return the 0s and 1s on the board (with
        //two spaces in between each 0 and 1)
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 15; j++) {
                System.out.print(x[i][j].getType() + "  ");
            }
            System.out.println();
        }
    }

    /**
     * Description: This method solves the best path to take from the start
     * coordinates to the goal coordinates
     * @param start
     * @param end
     * @param button
     */
    public static void solve(Node start, Node end, JButton[][] button) {

        //tells us that we are still searching for the best path
        boolean search = true;

        // creates open and closed lists
        // adds start point to list
        ArrayList<Node> openList = new ArrayList<Node>();
        ArrayList<Node> closedList = new ArrayList<Node>();
        openList.add(start);
        Node n = null;

        //while we are still searching for the path
        while (search) {

            n = openList.remove(0);
            //if we have reached the end of the path (goal) then search is false
            if (n.equals(end)) {
                search = false;
                
                //while n is not equal to the start 
                while (!n.equals(start)) {

                    n = n.getParent();
                    button[n.getRow()][n.getCol()].setBackground(Color.pink);

                } 
            } else {
                //set r and c equal to n's row and column destination
                int r = n.getRow();
                int c = n.getCol();
                
                //reviews all of the spaces around the current one to see if there are any...
                //unpathable spots.
                for (int i = r - 1; i <= r + 1; i++) {
                    for (int j = c - 1; j <= c + 1; j++) {

                        if ((i >= 0) && (i < 15) && (j >= 0) && (j < 15) && ((i != r) || (j != c))
                                && (button[i][j].getBackground() != Color.DARK_GRAY)) {

                            Node m = new Node(i, j, 0);
                            m.setParent(n);
                            int newG = 10;
                            if ((Math.abs(i - r) + Math.abs(j - c)) == 2) {
                                newG = 14;
                            } 
                            m.setG(n.getG() + newG);
                            m.setH(getH(m, end));
                            m.setF();
                            //checks to see if the coordinate is in the current closed list
                            if (inList(m, closedList) == null) {
                                Node q = inList(m, openList);
                                if (q == null) {
                                    openList.add(m);
                                } else {
                                    if (m.getG() < q.getG()) {
                                        q.setG(m.getG());
                                        q.setParent(n);

                                    } // end if
                                } // end else

                            } // end if
                            //    System.out.println("Node moved from " + n.getRow() + ", " + n.getCol());
                        } // end if

                    } // end loop 2
                } // end loop 1
                closedList.add(n);

            } // end while

        } // end while

    } // end method

    /**
     * Description: this method calculates the heuristic value
     * @param start
     * @param goal
     * @return
     */
    public static int getH(Node start, Node goal) {

        // intializes row variables
        int row, col, h;

        // sets the start rows and columns
        int sRow = start.getRow();
        int sCol = start.getCol();
        int gRow = goal.getRow();
        int gCol = goal.getCol();

        // Sets the variables
        // *10 for due to it being orthogonal
        row = Math.abs(sRow - gRow) * 10;
        col = Math.abs(sCol - gCol) * 10;
        h = row + col;

        return h;
    } // end method

    /**
     * Description: this method tests to see if the proposed coordinates are
     * in the current list
     * @param n
     * @param openList
     * @return
     */
    public static Node inList(Node n, ArrayList<Node> openList) {
        for (int i = 0; i < openList.size(); i++) {
            if (openList.get(i).equals(n)) {
                return openList.get(i);
            }
        }
        return null;
    }

    @Override
    public void actionPerformed(ActionEvent evt) {
        Object src = evt.getSource();
        if (src == button[0][0]) {
            //First button actions
            System.out.println("Clicked Button 0");
            button[0][0].setBackground(Color.green);
        } else if (src == button[1][1]) {
            System.out.println("Clicked Button 1");
        }

    }

}
