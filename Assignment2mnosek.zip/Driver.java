/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2__mnosek;

/**
 * Description: Controls the queue/heap for the entire program. Adds customers
 * to the line (25% chance) and removes customers when they have been serviced
 * @author mln98
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //initialize variables
        int maxLength = 0;
        int length = 0;
        int customersServiced = 0;
        
        PriorityCustomer cust = new PriorityCustomer(); //creates a prioritycustomer object called cust
        PriorityQueue queue = new PriorityQueue(); //creates a priorityqueue object called queue
        
        //loops the program 60 iterations, or 60 minutes
        for (int i = 0; i < 60; i++) {
            //creates a random number between 1 and 4
            int num = (int) ((Math.random() * 4) + 1);
            //if the number is 1, add a customer to the heap/queue
            if (num == 1){
                queue.add(cust);
                //increment the max length and length of the current line
                length++;
                maxLength++;
                System.out.println("New customer added!  Queue length is now " + length);
            }
            //if the number is not 1, then do not add a customer
            else{
                System.out.println("Customer has not been added to the queue");
            }
            //if the line is not empty, set the customer object equal to the root
            if (length != 0){
                cust = queue.getFirst();
            //if the customer service time is not zero, decrement the time
                if (cust.getServiceTime() != 0){
                    cust.decServiceTime(); 
                }
            //if the customer service time is zero then remove the customer from the queue
                else{
                    queue.remove(); //remove customer from heap/queue
                    length--; //decrement line length by 1
                    customersServiced++; //increment how many have been serviced by 1
                    System.out.println("Customer serviced and removed from the queue.  Queue length is now " + length);
                }
            }
        //prints out the end of the interation
        System.out.println("------------------------------------------------------------");     
        }
        //prints out the max length and the number of customers serviced throughout the 60 minutes
        System.out.println("Max Length: " + maxLength);
        System.out.println("Customers serviced: " + customersServiced);
    }
    
}
