/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2__mnosek;

/**
 * Description: class contains methods that may be used within the queue/heap, 
 * that control whether a priority customer object is being added, removed, or 
 * if their time is being decremented.
 * @author mln98
 */
public class PriorityQueue {
    //initialize fields for class 
    private PriorityCustomer[] heap;
    private int size;
    
    
    public PriorityQueue() {
        //sets the size of the heap
        heap = new PriorityCustomer[60];
        size = 0;
    }
    
    /**
     * Description: adds a customer to the heap
     * @param customer
     */
    public void add(PriorityCustomer customer){
        //checks to see if the heap is full
        if (size + 1 >= heap.length){
            System.out.println("The heap is full");
            return;
        }
        size++; //increase size by 1
        heap[size] = customer; //sets the heap size equal to customer
        int index = size; //sets the index equal to the size
        
        //while their is more that just the root in the heap
        while (index > 1) {
            int parentIndex = index / 2; //set the parent index equal to the current divided by 2
            
            //compare the current index to the parent index to see if they need to be swapped 
            if (heap[index].getPriority() > heap[parentIndex].getPriority()){ 
                //swap the two indexes
                PriorityCustomer temp = heap[index];
                heap[index] = heap[parentIndex];
                heap[parentIndex] = temp;
                index = parentIndex;
            }
            //otherwise, end
            else{
                break;
            }
        }
    }
    
    /**
     * Description: removes a customer from the heap based on priority
     * @return temp
     */
    public PriorityCustomer remove(){
        
        //checks to see if the heap is empty
        if (size == 0){
            System.out.println("The heap is empty");
            return null;
        }
        //set a temp variable equal to the root in the heap and swap
        PriorityCustomer temp = heap[1];
        heap[1] = heap[size];
        heap[size] = null;
        int index = 1;
        //decrement the size by 1
        size--;
        
        //compares indexes as long as there is more than a root in the heap
        while (index <= size / 2){
            //initialize the children/indexes greater than 1
            int leftIndex = index * 2;
            int rightIndex = leftIndex + 1;
            int leftValue = heap[leftIndex].getPriority();
            int rightValue = Integer.MIN_VALUE;
            
            //if the right index is less than the size, set the right value equal to the right index value/priority
            if (rightIndex <= size){
                rightValue = heap[rightIndex].getPriority();
            }
            //initialize some large values to compare the indexes
            int bigValue = 0;
            int bigIndex = 0;
            //if the right value is greater than the left, set the large value/index equal to the right
            if (rightValue > leftValue){
                bigValue = rightValue;
                bigIndex = rightIndex;
            }
            //otherwise, set the large value/index equal to the left
            else{
                bigValue = leftValue;
                bigIndex = leftIndex;
            }
            //if the large number is greater than the current index, swap
            if (bigValue > heap[index].getPriority()){
                PriorityCustomer swap = heap[index];
                heap[index] = heap[bigIndex];
                heap[bigIndex] = swap;
                index = bigIndex;
            }
            //otherwise, end
            else{
                break;
            }
        }
        //return the temp variable that was created at the beginning of the method
        return temp;
    }

    /**
     * Description: sets the heap equal to null
     * @return heap
     */
    public boolean isEmpty() {
        return heap == null;
    }
    
    /**
     * Description: returns the size
     * @return size
     */
    public int getSize() {
        return size;
    }
    
    /**
     * Description: sets the root of the heap
     * @return heap[1]
     */
    public PriorityCustomer getFirst(){
        return heap[1];
    }
}
