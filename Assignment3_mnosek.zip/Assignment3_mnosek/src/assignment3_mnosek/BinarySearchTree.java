/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3_mnosek;

/**
 * This class holds methods that control the tree operations, roots, and
 * children
 *
 * @author Margaret Nosek
 */
public class BinarySearchTree {

    //declare fields
    private Node root;

    public BinarySearchTree() {
    }

    /**
     * Makes something empty or null
     *
     * @return root
     */
    public boolean isEmpty() {
        return root == null;
    }

    /**
     * Returns the root
     *
     * @return
     */
    public Node getRoot() {
        return root;
    }

    /**
     * Inserts a string
     *
     * @param string
     */
    public void insert(String string) {
        if (isEmpty()) {
            root = new Node(string);
        } 
        else {
            if (freq(string, root) == false){
                root.insert(string);
            }
        }
        setFreq(string, count(string));
    }

    /**
     * Searches the left and right sides of the tree for a string and gets the
     * frequency
     *
     * @param string
     * @param node
     */
    public void search(String string, Node node) {
        if (node.string.equals(string)) {
            System.out.println(string + node.getFreq());
        }
        if (node.leftChild != null) {
            search(string, node.leftChild);
        }
        if (node.rightChild != null) {
            search(string, node.rightChild);
        }
    }

    /**
     * Searches for the string and prints out a statement if the string is found
     *
     * @param string
     */
    public void search(String string) {
        System.out.println(string + " string was located " + count(string) + " time(s)!");
    }

    /**
     * Counts the string
     *
     * @param string
     * @return
     */
    public int count(String string) {
        return countString(string, root);
    }

    /**
     * Checks the nodes in order to count strings
     *
     * @param string
     * @param node
     * @return
     */
    public int countString(String string, Node node) {
        int count = 0;
        if (node != null) {
            if (node.getString().equals(string)) {
                count++;
            }
            if (node.getLeftChild() != null) {
                count += countString(string, node.getLeftChild());
            }
            if (node.getRightChild() != null) {
                count += countString(string, node.getRightChild());
            }
        }
        return count;
    }

    /**
     * Sets the frequency
     *
     * @param string
     * @param f
     */
    public void setFreq(String string, int f) {
        freqUpdate(string, f, root);
    }

    /**
     * Increases the frequency if the string is found, returns true if the left
     * child is not equal to null and the frequency of a is equal to the left
     * child. Also returns true if the right child is not empty and a is equal
     * to the rightChild
     *
     * @param string
     * @param node
     * @return
     */
    public boolean freq(String string, Node node) {
        if (node.string.equals(string)) {
            node.incrementFreq();
            return true;
        } 
        else if (node.leftChild != null && freq(string, node.leftChild) == true) {
            return true;
        } 
        else if (node.rightChild != null && freq(string, node.rightChild) == true) {
            return true;
        } 
        else {
            return false;
        }
    }

    /**
     * Updates the frequency of the string
     *
     * @param string
     * @param f
     * @param node
     */
    public void freqUpdate(String string, int f, Node node) {
        if (node != null) {
            if (node.getString().equals(string)) {
                node.updateFreq(f);
            }
            if (node.getLeftChild() != null) {
                freqUpdate(string, f, node.getLeftChild());
            }
            if (node.getRightChild() != null) {
                freqUpdate(string, f, node.getRightChild());
            }
        }
    }

    /**
     * Prints from the top root down to the left child and continues to work to
     * the right
     *
     * @param root
     */
    public void preOrder(Node root) {
        if (root == null) {
            return;
        }
        System.out.print(root.string + ", ");
        preOrder(root.leftChild);
        preOrder(root.rightChild);
    }

    /**
     * Prints from the left children to the right children and up
     *
     * @param root
     */
    public void postOrder(Node root) {
        if (root.leftChild != null) {
            postOrder(root.leftChild);
        }
        if (root.rightChild != null) {
            postOrder(root.rightChild);
        }
        System.out.print(root.string + ", ");
    }

    /**
     * Prints exactly from the leftmost child to the rightmost child
     *
     * @param root
     */
    public void inOrder(Node root) {
        if (root == null) {
            return;
        }
        inOrder(root.leftChild);
        System.out.print(root.string + ", ");
        inOrder(root.rightChild);
    }

    /**
     * Prints out the preOrder
     */
    public void printPreOrder() {
        preOrder(root);
    }

    /**
     * prints out the postOrder
     */
    public void printPostOrder() {
        postOrder(root);
    }

    /**
     * prints the inOrder
     */
    public void printInOrder() {
        inOrder(root);
    }

}
