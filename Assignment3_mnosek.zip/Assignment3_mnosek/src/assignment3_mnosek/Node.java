/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3_mnosek;

/**
 * The Node class controls all variables and methods created in order to control
 * the operations of the tree
 *
 * @author Margaret Nosek
 */
public class Node {

    //declare fields and variables
    int frequency;
    String string;
    Node leftChild;
    Node rightChild;
    
    public Node(String s) {
        string = s;
        leftChild = null;
        rightChild = null;
        frequency = 1;
    }

    /**
     * Inserts new nodes as long as there aren't already two children per node
     *
     * @param string
     */
    public void insert(String string) {

        if (leftChild == null) {
            leftChild = new Node(string);
        } 
        else if (rightChild == null) {
            rightChild = new Node(string);
        } 
        else {
            if (countChildren(leftChild) <= countChildren(leftChild)) {
                leftChild.insert(string);
            } 
            else {
                rightChild.insert(string);
            }
        }
    }

    /**
     * Increments the frequency
     */
    public void incrementFreq() {
        frequency++;
    }

    /**
     * Updates the frequency of the words
     *
     * @param f
     * @return f
     */
    public int updateFreq(int f) {
        f = frequency++;
        return f;
    }

    /**
     * Counts the number of children using the given node (that is if the node
     * has children)
     *
     * @param node
     * @return
     */
    public int countChildren(Node node) {
        int count = 0;

        if (node != null) { //checks to see if there are children
            count = 1 + countChildren(node.getLeftChild()) + countChildren(node.getRightChild());
        }

        return count;
    }

    /**
     * Returns the frequency
     *
     * @return frequency
     */
    public int getFreq() {
        return frequency;
    }

    /**
     * Returns string variable
     *
     * @return string
     */
    public String getString() {
        return string;
    }

    /**
     * Returns the left part of the tree
     *
     * @return
     */
    public Node getLeftChild() {
        return leftChild;
    }

    /**
     * Returns the right part of the tree
     *
     * @return
     */
    public Node getRightChild() {
        return rightChild;
    }

}
