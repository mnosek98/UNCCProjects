/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eightqueens;

/**
 * Description: Purpose of this program is to create an 8x8 board with 8 queens randomly placed in each column.
 * The goal is to move each queen vertically along their respective column so that each queen is not in conflict
 * with each other (vertically, horizontally, diagonally) using the Hill Climb Method.
 * 
 * @author Margaret Nosek
 */
import java.util.*;
public class EightQueens {
    
    //initialize all variables used throughout program
    private int heuristic = 0;
    private int randomRestarts = 0;
    private int queenLocation = 0;
    private int numOfMoves = 0;
    private int neighborStates = 0;
    private boolean newBoard = true;
    private boolean randomRestart = true;
    
    //initialize 2D arrays used for the board
    final private int [][] board = new int[8][8];
    final private int [][] testBoard = new int [8][8];
    
    /**
     * Description: Creates the eight queens object in order to start the 
     * program and create the random 8x8 board.
     * @param args
     */
    public static void main(String[] args) {
        
        EightQueens game = new EightQueens(); //creates a new game object
        System.out.println("Welcome to the 8-Queens Problem");
        game.createRandomBoard();
        game.start(); //starts the 8 queens problem
    }

//    public EightQueens() {
//    }
    
    /**
     * Description: sets up the board using a nested loop and 
     * randomizes the spots the queens are located on
     */
    public void createRandomBoard(){
        for (int i = 0; i < 8; i++){ //nested for loop sets up board
            for(int j = 0; j < 8; j++){
                board[i][j] = 0;
            }
        }
        Random num = new Random(); //creates random object
        while (queenLocation < 8){
            for (int i = 0; i < 8; i++){ //places queens on random column locations
                board[num.nextInt(7)][i] = 1;
                queenLocation++;
            }
        }
        heuristic = findHeuristic(board);
    }
    
    /**
     * Description: locates any horizontal conflicts with the eight queens
     * @param testBoard
     * @param x
     * @return
     */
    public boolean getRowConflict(int [][] testBoard, int x){
        boolean conflictFound = false; //originally sets conflict to false
        int count = 0;
        
        for(int i = 0; i < 8; i++){ //goes through rows
            if(testBoard[i][x] == 1){ //uses the copy of the original board to find queens
                count++;
            }
        }
        if(count > 1){ //if one or more queens are found in the row then there is a conflict
            conflictFound = true;
        }
        else{
            conflictFound = false; //no queens means no conflict
        }
        return conflictFound; 
    }
    
    /**
     * Description: Looks for column conflicts (vertical, works the same way as getRowConflict)
     * @param testBoard
     * @param x
     * @return
     */
    public boolean getColConflict(int [][] testBoard, int x){
        boolean conflictFound = false;
        int count = 0;
        
        for(int i = 0; i < 8; i++){
            if(testBoard[x][i] == 1){
                count ++;
            }
        }
        if(count > 1){
            conflictFound = true;
        }
        else{
            conflictFound = false;
        }
        return conflictFound;
    }
    
    /**
     * Description: Searches for a conflict on the diagonal line
     * @param testBoard
     * @param x
     * @param y
     * @return
     */
    public boolean getDiagConflict(int [][] testBoard, int x, int y){
        boolean conflictFound = false;
        
        for (int i = 1; i < 8; i++){
            if(conflictFound){
                break;
            }
            if((x + i < 8) && (y + i < 8)){
                if(testBoard[x + i][y + i] == 1){
                    conflictFound = true;
                }
            }
            if((x - i >= 0) && (y - i >= 0)){
                if(testBoard[x - i][y - i] == 1){
                    conflictFound = true;
                }
            }
            if((x - i >= 0) && (y + i < 8)){
                if(testBoard[x - i][y + i] == 1){
                    conflictFound = true;
                }
            }
            if((x + i < 8) && (y - i >= 0)){
                if(testBoard[x + i][y - i] == 1){
                    conflictFound = true;
                }
            } 
        }  
        return conflictFound;
    }
    
    /**
     * Description: finds the heuristic value for the current state
     * @param testBoard
     * @return
     */
    public int findHeuristic(int[][]testBoard) {
        boolean diagConflict;
        boolean rowConflict;
        boolean colConflict;
        int count = 0;      
            for (int i = 0; i < 8; i++){
                for (int j = 0; j < 8; j++){
                    if (testBoard[i][j] == 1){
                        diagConflict = getDiagConflict(testBoard, i, j);
                        rowConflict = getRowConflict(testBoard, j);
                        colConflict = getColConflict(testBoard, i);
                        
                        if(rowConflict || colConflict || diagConflict){
                            count++;
                        }
                        
                    }
                }
            }
            return count;
    }
    
    /**
     * Description: checks to see if a random restart is necessary
     * @param testBoard
     * @return
     */
    public boolean checkRandomRestart(int[][] testBoard){
        randomRestart = false;
        int localMinima = 8;
        
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                if(testBoard[i][j] < localMinima){
                    localMinima = testBoard[i][j];
                }
            }
        }
        if(neighborStates == 0){ //if the there are no neighboring states then a random restart is necessary
            randomRestart = true;
        }
        return randomRestart;
    }
    
    /**
     * Description: restarts the board to a completely new random board
     */
    public void randomRestart(){
        queenLocation = 0;
        
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                board[i][j] = 0;
            }
        }
        createRandomBoard();
        System.out.println("RANDOM RESTART");
        randomRestarts++;
    }
    
//    public void checkForSolution(int []][] testBoard){
//        if(findHeuristic(board) == 0){
//            System.out.println("\nCurrentState");
//            for(int i = 0; i < 8; i++){
//                for(int j = 0; j < 8; j++){
//                System.out.println(board[i][j] + " ");
//                }
//            }
//            System.out.println("Solution Found!");
//            System.out.println("State changes: " + numOfMoves);
//            System.out.println("Restarts: " + randomRestarts);
//        }
//        else{
//            System.out.println("Current h: " + heuristic);
//            System.out.println("Current State: ");
//            for(int i = 0; i < 8; i++){
//                for(int j = 0; j < 8; j++){
//                    System.out.println(board[i][j] + " ");
//                }
//            }
//            System.out.println("Neighbors found with lower h: " + neighborStates);
//            System.out.println("Setting new current state");
//        }
//        
//    }

    /**
     * Description: searches for the minimum state in the current column
     * @param testBoard
     * @return
     */
    
    public int getMinColumnState(int[][] testBoard){
        //initialize min variables
        int minColumnState = 8;
        int min = 8;
        int count = 0;
        
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                if(testBoard[i][j] < min){ //checks to see if current position is lower than 8
                    min = testBoard[i][j];
                    minColumnState = j;
                }
                if(testBoard[i][j] < heuristic){ //if state is lower than the heuristic value, increase the neighboring states count
                    count++;
                }
            }
        }
        neighborStates = count;
        return minColumnState;
    }
    
    /**
     * Description: searches for the the minimum state in the current rows 
     * @param testBoard
     * @return
     */
    public int getMinRowState(int[][] testBoard){
        //initialize min variables
        int minRowState = 8;
        int min = 8;
        
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                if(testBoard[i][j] < min){ //checks to see if current position is lower than 8
                    min = testBoard[i][j];
                    minRowState = i;
                }
            }
        }
        return minRowState;
    }
    
    /**
     * Description: moves the queens around to find the lowest heuristic value (hoping for 0), uses the check for random
     * restart, and also checks to see if a solution has been found. 
     */
    public void start(){
        //initializes variables and arrays 
        newBoard = false;
        int [][] array = new int[8][8];
        int count;
        int localMinimaCol;
        int localMinimaRow;
        int lastQueen = 0;
        
        while(true){
            count = 0;
            for(int i = 0; i < 8; i++){
                System.arraycopy(board[i], 0 , testBoard[i], 0 , 8); //makes a copy of the board being used
            }
            while(count < 8){
                for(int i = 0; i < 8; i++){ //checks for queens 
                    if(board[i][count] == 1){
                        lastQueen = i; //saves location of last queen
                    }
                    testBoard[i][count] = 1;
                    array[i][count] = findHeuristic(testBoard);
                    testBoard[i][count] = 0;
                }
                testBoard[lastQueen][count] = 1;
                count++;
            }
            
            if (checkRandomRestart(array) == true){ //checks to see if a restart is necessary
                randomRestart();
            }
            
            localMinimaCol = getMinColumnState(array); //sets the values of the local minimas for the column and row
            localMinimaRow = getMinRowState(array);
            
            for(int i = 0; i < 8; i++){
                board[i][localMinimaCol] = 0;
            }
            //after making a move, increments the move and sets the current heuristic value (this only happens after
            //finding another lower hueristic value than the current one
            board[localMinimaRow][localMinimaCol] = 1;
            numOfMoves++;
            heuristic = findHeuristic(board);
            
            //if the heuristic is equal to 0 then prints out the 8x8 board and prints the solution has been found
            if(findHeuristic(board) == 0){
            System.out.println("CurrentState");
            for(int i = 0; i < 8; i++){
                for(int j = 0; j < 8; j++){
                System.out.print(board[i][j] + ",");
                }
                System.out.print("\n");
            }
            System.out.println("Solution Found!");
            System.out.println("State changes: " + numOfMoves);
            System.out.println("Restarts: " + randomRestarts);
            break;
        }
            //if the heuristic value is not equal to zero then continue finding lower h values 
            System.out.println("Current h: " + heuristic);
            System.out.println("Current State: ");
            for(int i = 0; i < 8; i++){
                for(int j = 0; j < 8; j++){
                    System.out.print(board[i][j] + ",");
                }
                System.out.print("\n");
            }
            System.out.println("Neighbors found with lower h: " + neighborStates);
            System.out.println("Setting new current state");
        }
        }
        
        
    }
      
    

