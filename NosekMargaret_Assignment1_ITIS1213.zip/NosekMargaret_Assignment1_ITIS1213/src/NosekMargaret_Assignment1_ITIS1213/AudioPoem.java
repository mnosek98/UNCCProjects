/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NosekMargaret_Assignment1_ITIS1213;

import BookClasses.FileChooser;
import BookClasses.Sound;
import BookClasses.SoundException;
import BookClasses.SoundSample;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The AudioPoem class contains methods that manipulate a sound file like: 
 * play, play doublets, play random order, play unique random, play reverse,
 * and play triplets. The class also contains overloaded methods that save a 
 * new sound just like the original methods.
 *
 * @author Margaret Nosek
 */
public class AudioPoem {

    static final int MAX_NUM_WORDS = 100;
    static private Sound[] myWordArray = new Sound[MAX_NUM_WORDS];
    static private int numWords = 0;

    String path = "C:\\Users\\mln98\\Desktop\\mediasources\\mediasources\\";
    String filename = "thisisatest.wav";

    /**
     * 
     * @param originalSource
     * @param spliceArray
     * @param numSplicePoints
     */
    public AudioPoem(Sound originalSource, int[] spliceArray, int numSplicePoints) {

        // break the sound into sepearate words, copying each into the word array
        for (int i = 0, j = 0; i < numSplicePoints; i = i + 2, j++) {
            myWordArray[j] = new Sound(spliceArray[i + 1] - spliceArray[i]);
            for (int x = spliceArray[i], y = 0; x < spliceArray[i + 1]; x++, y++) {
                myWordArray[j].setSampleValueAt(y, originalSource.getSampleValueAt(x));
            }
            numWords++;
        }

    }
    /**
     *Description: Plays the words, in order with a 200 millisecond pause 
     *between each word
     *
     * @throws InterruptedException
     */
    public void play() throws InterruptedException {
        // play the words in order
        for (int i = 0; i < numWords; i++) {
            myWordArray[i].blockingPlay(); //plays each word in the array
            Thread.sleep(200); //200 millisecond pause
        }
    }
    /**
     *Description: Plays the words, in order with a parameter-specified pause
     * between each word
     *
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void play(int pause) throws InterruptedException {
        //plays the words in order
        for (int i = 0; i < numWords; i++) {
            myWordArray[i].blockingPlay(); //plays each word
            Thread.sleep(pause); //pauses for a parameter-specified time

        }
    }
    /**
     * Description: Plays the words, in order with a parameter-specified pause between each
     * and writes the sound to a file
     *
     * @param pause the number of milliseconds to pause between words
     * @param filename the name of the file to write
     * @param path the path where the file should be written
     * @throws InterruptedException
     */
    public void play(int pause, String filename, String path) throws InterruptedException {
        for (int i = 0; i < numWords; i++) { //plays words
            myWordArray[i].blockingPlay();
            Thread.sleep(pause);
        }
        int sum = 0;
        for (int i = 0; i < numWords; i++) { //loops to add the number of samples to sum
            sum += myWordArray[i].getNumSamples();
            double numPauses = (pause * myWordArray[i].getSamplingRate()) / 1000; //declares the number of pauses
            sum += numPauses; //adds number of pauses to sum

        }
        Sound newSound = new Sound(sum);
        int count = 0;
        for (int j = 0; j < numWords; j++) {
            for (int p = 0; p < myWordArray[j].getNumSamples(); p++) {
                int value = myWordArray[j].getSampleValueAt(p);
                newSound.setSampleValueAt(count, value);
                count++;
            }
            for (int k = 0; k < numWords; k++) {
                newSound.setSampleValueAt(count, 0);
                count++;
            }
        }
        newSound.write(path + filename); //writes to a file

    }
    /**
     * Description: Plays random pairs of consecutive words with only a 100 millisecond pause
     * between them, with a four hundred millisecond pause between pairs Ex: for
     * 'this is a test' a pair would only be 'this is' or 'is a' or 'a test'
     *
     * @param numDoublets the number of doublets to play
     * @throws InterruptedException
     */
    public void playDoublets(int numDoublets) throws InterruptedException {
        //for the number of doublets requested
        for (int i = 0; i < numDoublets; i++) {
            //generate a random number within the num of Words
            int randomNum = (int) (Math.random() * (numWords - 1));
            myWordArray[randomNum].blockingPlay();
            Thread.sleep(100);
            myWordArray[randomNum + 1].blockingPlay();
            Thread.sleep(400);
        }
    }
    /**
     *Description: Plays random pairs of words with 100 millisecond pauses between them
     * with pauses between the pairs and writes it to a file
     * 
     * @param numDoublets
     * @param filename
     * @param path
     * @throws InterruptedException
     */
    public void playDoublets(int numDoublets, String filename, String path) throws InterruptedException {
        for (int i = 0; i < numDoublets; i++) {
            //generate a random number within the num of Words
            int randomNum = (int) (Math.random() * (numWords - 1));
            myWordArray[randomNum].blockingPlay();
            Thread.sleep(100);
            myWordArray[randomNum + 1].blockingPlay();
            Thread.sleep(400);
        }
        int sum = 0;
        for (int i = 0; i < numWords; i++) { //loops to add the number of samples to sum
            sum += myWordArray[i].getNumSamples();
            numDoublets = (int) (numDoublets * myWordArray[i].getSamplingRate()) / 1000; //finds the number of doublets
            sum += numDoublets; //adds the number of doublets to sum
        }
        Sound newSound = new Sound(sum); //creates a new sound from sum
        int count = 0;
        for (int j = 0; j < numWords; j++) { //saves the words to the new sound
            for (int p = 0; p < myWordArray[j].getNumSamples(); p++) {
                int value = myWordArray[j].getSampleValueAt(p);
                newSound.setSampleValueAt(count, value);
                count++;
            }
            for (int k = 0; k < numWords; k++) {
                newSound.setSampleValueAt(count, 0);
                count++;
            }
        }
        newSound.write(path + filename); //writes new sound to a file
    }
    /**
     *Description: Plays the words in random order, each word can be played multiple times
     *
     * @param totalWords the total number of words that will be played
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void playRandomOrder(int totalWords, int pause) throws InterruptedException {
        for (int i = 0; i < totalWords; i++) { //loops through the words
            myWordArray[((int) Math.random() * 4)].blockingPlay(); //selects random words
            Thread.sleep(pause); 
        }
    }
    /**
     *Description: plays the words in random order, each word can be played multiple times, 
     * and writes the sound to a file
     * @param totalWords
     * @param pause
     * @param filename
     * @param path
     * @throws InterruptedException
     */
    public void playRandomOrder(int totalWords, int pause, String filename, String path) throws InterruptedException {
        for (int i = 0; i < totalWords; i++) { //loops through the words
            myWordArray[((int) Math.random() * 4)].blockingPlay(); //selects random words
            Thread.sleep(pause);
        }
        int sum = 0;
        for (int i = 0; i < numWords; i++) { //loops to add the number of samples to sum
            sum += myWordArray[i].getNumSamples();
            totalWords = (int) (totalWords * myWordArray[i].getSamplingRate()) / 1000; //finds the total number of words
            sum += totalWords; //adds total words to sum
        }
        Sound newSound = new Sound(sum); //creates a new sound from sum
        int count = 0;
        for (int j = 0; j < numWords; j++) { //loops through the words 
            for (int p = 0; p < myWordArray[j].getNumSamples(); p++) { 
                int value = myWordArray[j].getSampleValueAt(p);
                newSound.setSampleValueAt(count, value);
                count++;
            }
            for (int k = 0; k < numWords; k++) { 
                newSound.setSampleValueAt(count, 0);
                count++;
            }
        }
        newSound.write(path + filename); //writes to a file
    }
    /**
     * Description: Plays the words in random order, playing each word only once
     *
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void playRandomUnique(int pause) throws InterruptedException {
        int randNumArray[] = new int[numWords];

        //generate random number for int list
        for (int i = 0; i < numWords; i++) {
            randNumArray[i] = ((int) (Math.random() * numWords));

            for (int j = 0; j < i; j++) { //loops through numWords to set an index equal to that another word's index
                if (randNumArray[i] == randNumArray[j]) {
                    i--;
                    break;
                }
            }
        }
        // play the words in constructed order
        for (int i = 0; i < numWords; i++) {
            int num = randNumArray[i];
            myWordArray[num].blockingPlay();
            Thread.sleep(pause);
        }

    }
    /**
     *Description: Plays the words in random order, only playing the words once,
     * and writes it to a file.
     * @param pause
     * @param filename
     * @param path
     * @throws InterruptedException
     */
    public void playRandomUnique(int pause, String filename, String path) throws InterruptedException {
        int randNumArray[] = new int[numWords];

        //generate random number for int list
        for (int i = 0; i < numWords; i++) {
            randNumArray[i] = ((int) (Math.random() * numWords));

            for (int j = 0; j < i; j++) { //loops through numWords to set an index equal to that another word's index
                if (randNumArray[i] == randNumArray[j]) {
                    i--;
                    break;
                }
            }
        }
        // play the words in constructed order
        for (int i = 0; i < numWords; i++) {
            int num = randNumArray[i];
            myWordArray[num].blockingPlay();
            Thread.sleep(pause);
        }
        int sum = 0;
        for (int i = 0; i < numWords; i++) { //loops through the words 
            sum += myWordArray[i].getNumSamples();
            int numPauses = (int) (pause * myWordArray[i].getSamplingRate()) / 1000; //finds the number of pauses
            sum += numPauses; //adds the number of pauses to sum
        }
        Sound newSound = new Sound(sum);
        int count = 0;
        for (int j = 0; j < numWords; j++) { //copies the words into the new sound
            for (int p = 0; p < myWordArray[j].getNumSamples(); p++) {
                int value = myWordArray[j].getSampleValueAt(p);
                newSound.setSampleValueAt(count, value);
                count++;
            }
            for (int k = 0; k < numWords; k++) {
                newSound.setSampleValueAt(count, 0);
                count++;
            }
        }
        newSound.write(path + filename); //writes to a file
    }
    /**
     * Description: Plays the sound words in reverse order (e.g. 'this is a test' will be
     * played 'test a is this')
     *
     * @param pause the number of milliseconds to pause between words
     * @throws InterruptedException
     */
    public void playReverseOrder(int pause) throws InterruptedException {
        for (int i = (numWords - 1); i >= 0; i--) { //loops through the words in reverse
            myWordArray[i].blockingPlay(); 
            Thread.sleep(pause);
        }

    }
    /**
     *Description: plays the words in reverse order and writes it to a file
     * @param pause
     * @param filename
     * @param path
     * @throws InterruptedException
     */
    public void playReverseOrder(int pause, String filename, String path) throws InterruptedException {
        for (int i = (numWords - 1); i >= 0; i--) { //loops through the words in reverse
            myWordArray[i].blockingPlay();
            Thread.sleep(pause);
        }
        int sum = 0;
        for (int i = 0; i < numWords; i++) {
            sum += myWordArray[i].getNumSamples();
            int numPauses = (int) (pause * myWordArray[i].getSamplingRate()) / 1000; //finds the number of pauses
            sum += numPauses; //adds numPauses to sum
        }
        Sound newSound = new Sound(sum); //creates a new sound
        int count = 0;
        for (int j = 0; j < numWords; j++) { //copies the words into the new sound
            for (int p = 0; p < myWordArray[j].getNumSamples(); p++) {
                int value = myWordArray[j].getSampleValueAt(p);
                newSound.setSampleValueAt(count, value);
                count++;
            }
            for (int k = 0; k < numWords; k++) {
                newSound.setSampleValueAt(count, 0);
                count++;
            }
        }
        newSound.write(path + filename); //writes to a file
    }
    /**
     *Description: plays triplets of words with pauses in between
     * @param numTriplets
     * @throws InterruptedException
     */
    public void playTriplets(int numTriplets) throws InterruptedException {
        //for the number of triplets requested
        for (int i = 0; i < numTriplets; i++) {
            //generate a random number within the num of Words
            int randomNum = 0 + (int) (Math.random() * (numWords - 1));

            myWordArray[randomNum].blockingPlay();
            Thread.sleep(100);
            myWordArray[randomNum + 1].blockingPlay();
            Thread.sleep(400);
            myWordArray[randomNum + 2].blockingPlay();
            Thread.sleep(800);

        }
    }
}
