package TicTacToeGame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Sets up the start screen and holds the startGame() method
 * @author Margaret Nosek
 */
public class GameController {
    private GameDataModel myModel;
    private StartScreen myStartScreen;
    private GameBoard myGameBoard;
    
    /**
     * Description: Takes in my model and creates the start screen for the game
     * @param myModel
     */
    public GameController(GameDataModel myModel) {
        this.myModel = myModel; 
        myStartScreen = new StartScreen(myModel, this);
        myStartScreen.setVisible(true);
        
    }
    
    /**
     * Description: starts the TicTacToe game
     * 
     */
    public void startGame() {
        myModel.startGame();
        
        
    }
    
   
    
    
    
}
