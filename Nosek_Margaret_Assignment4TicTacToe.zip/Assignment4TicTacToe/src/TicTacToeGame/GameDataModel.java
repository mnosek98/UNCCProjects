package TicTacToeGame;

import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * This class controls the actual game itself (holds methods that handle tokens and players)
 * @author Margaret Nosek
 */
public class GameDataModel {
    //initializes all the fields
    private Player p1;
    private Player p2;
    private int numPlayers = 0;
    private boolean gameStarted = false;
    private boolean gameOver = false;
    final private int MAX_ROUNDS = 4;
    private int round = 0;
    private boolean twoPlayers;
    private boolean gameModeSelected = false;
    private boolean p1Turn;
    private Win win = Win.NONE;
    private int turnCounter = 0;
    
    private Token[] gameArray = new Token[9];

    /**
     * Description: returns the max number of rounds that can be played
     * @return
     */
    public int getMAX_ROUNDS() {
        return MAX_ROUNDS;
    }

    /**
     * Description: returns the current round
     * @return
     */
    public int getRound() {
        return round;
    }

    /**
     * Description: sets the round as long as it's less than the max rounds
     * @param round
     */
    public void setRound(int round) {
        if (round <= MAX_ROUNDS)
            this.round = round;
    }

    /**
     * Description: gets player 1 information
     * @return
     */
    public Player getP1() {
        return p1;
    }

    /**
     * Description: sets player 1 information
     * @param p1
     */
    public void setP1(Player p1) {
        this.p1 = p1;
    }

    /**
     * Description: gets player 2 information
     * @return
     */
    public Player getP2() {
        return p2;
    }

    /**
     * Description: sets player 2 information
     * @param p2
     */
    public void setP2(Player p2) {
        this.p2 = p2;
    }
    
    /**
     * Description: checks to see if the game has started
     * @return
     */
    public boolean isGameStarted() {
        return gameStarted;
    }

    /**
     * Description: sets the gameStarted field with a boolean value
     * @param gameStarted
     */
    public void setGameStarted(boolean gameStarted) {
        this.gameStarted = gameStarted;
    }

    /**
     * Description: checks to see if the game is over
     * @return
     */
    public boolean isGameOver() {
        return gameOver;
    }

    /**
     * Description: sets the gameOver field with a boolean value
     * @param gameOver
     */
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    /**
     * Description: checks to see if it is a two player game
     * @return
     */
    public boolean isTwoPlayers() {
        return twoPlayers;
    }

    /**
     * Description: sets the mode of the game (sets two player)
     * @param twoPlayers
     */
    public void setTwoPlayers(boolean twoPlayers) {
        this.twoPlayers = twoPlayers;
        this.gameModeSelected = true;
    }
    /**
     * Description: adds a new player to the game
     * @param name 
     */
    void addNewPlayer(String name) {
        if (numPlayers == 0) { //if the number of players is equal to zero
            p1 = new Player(name); //set the player 1 name
            numPlayers += 1; //increment the number of players
        } else if (numPlayers == 1) { //if the number is equal to 1 player
            p2 = new Player(name); //set the player 2 name
            numPlayers += 1; //increment the number of players
        } else { //otherwise outputs an error message
            System.out.println("Shouldn't get here - trying to add more than one player");
        }
    }

    /**
     * Description: checks to see if the game is ready
     * @return
     */
    public boolean isGameReady() {
        // check to see if players have been set up
        boolean ready = false; 
        if (twoPlayers == false) {
            if (p1 != null) {
                p2 = new Player("Computer");
                numPlayers++;
                ready = true;
            }
        } else  { //basically sets the game equal to ready if both player names are not empty
            if ((p1 != null) && (p2 != null)) {
                ready = true;
            }
        }
        return ready;
    }

    /**
     * Description: returns the game mode
     * @return
     */
    public boolean selectedGameMode() {
       return gameModeSelected;
    }
    
    /**
     * Description: starts the TicTacToe game
     */
    public void startGame() {
        gameStarted = true;
        startNewRound();
    }
    
    /**
     * Description: starts a new round to the game
     */
    public void startNewRound(){
        //adds 1 to the round
        round ++;
        gameOver = false;
        p1Turn = true;
        win = Win.NONE;
        turnCounter = 0;
        //if it is 2 player mode, randomly select who goes first
        if (twoPlayers) {
            double temp = Math.random();
            if (temp > 0.5) {
                p1Turn = false;
                System.out.println("P2 goes first.");
            } else {
                System.out.println("P1 goes first");
            }
        }
        //sets the game board
        for (int i = 0; i< 9; i++) {
            gameArray[i] = Token.Blank;      
        }
        
        GameBoard myGameBoard = new GameBoard(this);
        myGameBoard.setVisible(true);
    }
    
    /**
     * Description: changes the token to an X or O, checks to see if its blank, also
     * checks for a tie or win
     * @param index
     * @return
     */
    public boolean changeToken(int index) {
        // make sure this space is blank, if not return
        
        
        if (gameArray[index] != Token.Blank) {
            System.out.println("Space is already used");
            return false;
        }
        
        // get token for player
        Token t;
        if (p1Turn) {
            t = Token.X;
        } else {
            t = Token.O;
        }
        
        // set token at index
        gameArray[index] = t;
        turnCounter ++;
        
        System.out.println("changes token");
        
        // see if won, if so, game is over and return true
        if (checkForWin(index)) {
            
            System.out.println("Wins!");
            gameOver = true;
            return true;
        }
        //checks for a tie if its the last turn and there is no win
        if (turnCounter == 9){
            System.out.println("Tie!");
            gameOver = true;
            win = win.NONE;
            return true;
        }
        
        
        // change turns
        p1Turn = !p1Turn;
        return true;
         
    }
    
    /**
     * Description: checks to see if a space is blank
     * @param index
     * @return
     */
    public boolean isSpaceBlank(int index) {
        if (gameArray[index] == Token.Blank) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Description: checks to see if its player 1's turn
     * @return
     */
    public boolean isP1Turn() {
        return p1Turn;
    }
    
    /**
     * Description: checks to see if there is a win in any spots
     * @param index
     * @return
     */
    public boolean checkForWin(int index) {
        boolean over = false;
        //check to see if there is a winner. If so, set win field and return true; otherwise, return false
        switch (index) {
                case 0:
                    if(gameArray[index].compareTo(gameArray[1]) == 0 && gameArray[index].compareTo(gameArray[2]) == 0){ //if index 0,1,2 are filled
                        over = true; //game over = true
                        win = win.TOP_ROW; //top row win
                    }
                    if(gameArray[index].compareTo(gameArray[3]) == 0 && gameArray[index].compareTo(gameArray[6]) == 0){
                        over = true;
                        win = win.LEFT_COL;
                    }
                    if(gameArray[index].compareTo(gameArray[4]) == 0 && gameArray[index].compareTo(gameArray[6]) == 0){
                        over = true;
                        win = win.DIAG1;
                    }
                break;
                case 1:
                    if(gameArray[index].compareTo(gameArray[0]) == 0 && gameArray[index].compareTo(gameArray[2]) == 0){
                        over = true;
                        win = win.TOP_ROW;
                    }
                    if(gameArray[index].compareTo(gameArray[4]) == 0 && gameArray[index].compareTo(gameArray[7]) == 0){
                        over = true;
                        win = win.MID_COL;  
                    }
                break;
                case 2:
                    if(gameArray[index].compareTo(gameArray[1]) == 0 && gameArray[index].compareTo(gameArray[0]) == 0){
                        over = true;
                        win = win.TOP_ROW;
                    }
                    if(gameArray[index].compareTo(gameArray[4]) == 0 && gameArray[index].compareTo(gameArray[6]) == 0){
                        over = true;
                        win = win.DIAG2;
                    }
                    if(gameArray[index].compareTo(gameArray[5]) == 0 && gameArray[index].compareTo(gameArray[8]) == 0){
                        over = true;
                        win = win.RIGHT_COL;
                    }
                break;
                case 3:
                    if(gameArray[index].compareTo(gameArray[0]) == 0 && gameArray[index].compareTo(gameArray[6]) == 0){
                        over = true;
                        win = win.LEFT_COL;
                    }
                    if(gameArray[index].compareTo(gameArray[4]) == 0 && gameArray[index].compareTo(gameArray[5]) == 0){
                        over = true;
                        win = win.MID_ROW;
                    }
                break;
                case 4: 
                   if(gameArray[index].compareTo(gameArray[0]) == 0 && gameArray[index].compareTo(gameArray[8]) == 0){
                        over = true;
                        win = win.DIAG1;
                    }
                   if(gameArray[index].compareTo(gameArray[3]) == 0 && gameArray[index].compareTo(gameArray[5]) == 0){
                        over = true;
                        win = win.MID_ROW;
                    }
                   if(gameArray[index].compareTo(gameArray[6]) == 0 && gameArray[index].compareTo(gameArray[2]) == 0){
                        over = true;
                        win = win.DIAG2;
                    }
                   if(gameArray[index].compareTo(gameArray[1]) == 0 && gameArray[index].compareTo(gameArray[7]) == 0){
                        over = true;
                        win = win.MID_COL;
                    }
                break;
                case 5:
                    if(gameArray[index].compareTo(gameArray[2]) == 0 && gameArray[index].compareTo(gameArray[8]) == 0){
                        over = true;
                        win = win.RIGHT_COL;
                    }
                    if(gameArray[index].compareTo(gameArray[3]) == 0 && gameArray[index].compareTo(gameArray[4]) == 0){
                        over = true;
                        win = win.MID_ROW;
                    }
                break;
                case 6:
                    if(gameArray[index].compareTo(gameArray[2]) == 0 && gameArray[index].compareTo(gameArray[4]) == 0){
                        over = true;
                        win = win.DIAG2;
                    }
                    if(gameArray[index].compareTo(gameArray[0]) == 0 && gameArray[index].compareTo(gameArray[3]) == 0){
                        over = true;
                        win = win.LEFT_COL;
                    }
                    if(gameArray[index].compareTo(gameArray[7]) == 0 && gameArray[index].compareTo(gameArray[8]) == 0){
                        over = true;
                        win = win.BOT_ROW;
                    }
                break;
                case 7:
                    if(gameArray[index].compareTo(gameArray[6]) == 0 && gameArray[index].compareTo(gameArray[8]) == 0){
                        over = true;
                        win = win.BOT_ROW;
                    }
                    if(gameArray[index].compareTo(gameArray[1]) == 0 && gameArray[index].compareTo(gameArray[4]) == 0){
                        over = true;
                        win = win.MID_ROW;
                    }
                break;
                case 8:
                    if(gameArray[index].compareTo(gameArray[0]) == 0 && gameArray[index].compareTo(gameArray[4]) == 0){
                        over = true;
                        win = win.DIAG1;
                    }
                    if(gameArray[index].compareTo(gameArray[6]) == 0 && gameArray[index].compareTo(gameArray[7]) == 0){
                        over = true;
                        win = win.BOT_ROW;
                    }
                    if(gameArray[index].compareTo(gameArray[2]) == 0 && gameArray[index].compareTo(gameArray[5]) == 0){
                        over = true;
                        win = win.RIGHT_COL;
                    }
                break;
                     
        }
                
        return over;
        
    }
    /**
     * Description: returns the token at an index
     * @param i
     * @return 
     */
    Token getToken(int i) {
        return gameArray[i];
    }
    
    /**
     * Description: returns the win
     * @return
     */
    public Win getWin() {
        return win;
    }
}
//sets enumerated types for the token and type of win
enum Token { X, O, Blank};

enum Win {NONE, TOP_ROW, MID_ROW, BOT_ROW, LEFT_COL, MID_COL, RIGHT_COL, DIAG1, DIAG2};