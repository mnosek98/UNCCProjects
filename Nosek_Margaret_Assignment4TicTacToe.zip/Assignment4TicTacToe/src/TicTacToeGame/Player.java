package TicTacToeGame;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Class that holds player information
 * @author Margaret Nosek
 */
public class Player {
    private String name;
    private int roundsWon;

    Player(String name) {
        this.name = name;
        this.roundsWon = 0;
    }

    /**
     * Description: returns the name of the player
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Description: sets the name of the player
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Description: gets how many rounds are won
     * @return
     */
    public int getRoundsWon() {
        return roundsWon;
    }

    /**
     * Description: sets how many rounds are won
     * @param roundsWon
     */
    public void setRoundsWon(int roundsWon) {
        this.roundsWon = roundsWon;
    }

    /**
     * Description: return the rounds won
     */
    public void roundsWon(){
        this.roundsWon++;
    }
  
    
    
}
